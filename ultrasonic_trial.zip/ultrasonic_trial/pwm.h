/*
 * pwm.h
 *
 *  Created on: Sep 26, 2025
 *      Author: Haneen
 */

#ifndef PWM_H_
#define PWM_H_

#include "std_types.h"
#include "avr/io.h"

void PWM_Timer0_Start(uint8 duty_cycle);

#endif /* PWM_H_ */
