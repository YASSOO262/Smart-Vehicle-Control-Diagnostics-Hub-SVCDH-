#include "led.h"
#include <avr/io.h>

void LED_init(void) {
    /* Configure PB3/OC0 as output pin */
    LED_PORT_DIR |= (1 << LED_PIN);

    /* Initialize Timer0 initial value */
    TCNT0 = 0;

    /* Initialize OCR0 with 0 (LED off initially) */
    OCR0 = 0;

    /*
     * Configure timer control register TCCR0:
     * 1. Fast PWM mode FOC0=0, WGM00=1, WGM01=1
     * 2. Clear OC0 on compare match (Non-inverting mode) COM00=0, COM01=1
     * 3. Clock = F_CPU/8 CS00=0, CS01=1, CS02=0
     */
    TCCR0 = (1 << WGM00) | (1 << WGM01) | (1 << COM01) | (1 << CS01);
}

void LED_setIntensity(uint8 duty_cycle) {
    /* Update the compare match register with the duty cycle value */
    OCR0 = duty_cycle;
}
