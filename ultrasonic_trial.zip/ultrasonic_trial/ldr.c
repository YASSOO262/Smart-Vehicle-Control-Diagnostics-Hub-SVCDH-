#include "ldr.h"
#include "adc.h"

uint16 LDR_getLightIntensity(void) {
    return ADC_readChannel(LDR_SENSOR_CHANNEL);
}
