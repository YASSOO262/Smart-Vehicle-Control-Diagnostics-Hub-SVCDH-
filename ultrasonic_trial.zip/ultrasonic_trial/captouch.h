#ifndef TOUCH_H_
#define TOUCH_H_

#include "std_types.h"

#define TOUCH_PORT_ID   PORTB_ID
#define TOUCH_PIN_ID    PIN2_ID

/* Initializes the pin as input */
void Touch_init(void);

/* Returns 1 if touched, 0 if not (Polling method) */
uint8 Touch_getState(void);

#endif
