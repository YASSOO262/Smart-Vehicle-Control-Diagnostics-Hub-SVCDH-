fan.o fan.o: ../fan.c ../fan.h ../std_types.h ../gpio.h

../fan.h:

../std_types.h:

../gpio.h:
