dht11.o dht11.o: ../dht11.c ../dht11.h ../std_types.h ../gpio.h

../dht11.h:

../std_types.h:

../gpio.h:
