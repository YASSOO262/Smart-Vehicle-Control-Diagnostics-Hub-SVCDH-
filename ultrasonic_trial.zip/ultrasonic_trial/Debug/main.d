main.o main.o: ../main.c ../lcd.h ../std_types.h ../external_eeprom.h \
  ../twi.h ../adc.h ../pwm.h ../gpio.h ../ultrasonic.h ../dht11.h \
  ../mq2.h ../captouch.h ../buzzer.h ../fan.h ../button.h ../uart.h

../lcd.h:

../std_types.h:

../external_eeprom.h:

../twi.h:

../adc.h:

../pwm.h:

../gpio.h:

../ultrasonic.h:

../dht11.h:

../mq2.h:

../captouch.h:

../buzzer.h:

../fan.h:

../button.h:

../uart.h:
