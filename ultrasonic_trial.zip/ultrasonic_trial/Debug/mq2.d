mq2.o mq2.o: ../mq2.c ../mq2.h ../std_types.h ../gpio.h

../mq2.h:

../std_types.h:

../gpio.h:
