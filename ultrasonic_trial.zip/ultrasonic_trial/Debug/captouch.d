captouch.o captouch.o: ../captouch.c ../captouch.h ../std_types.h \
  ../gpio.h

../captouch.h:

../std_types.h:

../gpio.h:
