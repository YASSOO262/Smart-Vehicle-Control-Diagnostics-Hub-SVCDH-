################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../adc.c \
../button.c \
../buzzer.c \
../captouch.c \
../dht11.c \
../external_eeprom.c \
../fan.c \
../gpio.c \
../lcd.c \
../ldr.c \
../led.c \
../main.c \
../mq2.c \
../pwm.c \
../twi.c \
../uart.c \
../ultrasonic.c 

OBJS += \
./adc.o \
./button.o \
./buzzer.o \
./captouch.o \
./dht11.o \
./external_eeprom.o \
./fan.o \
./gpio.o \
./lcd.o \
./ldr.o \
./led.o \
./main.o \
./mq2.o \
./pwm.o \
./twi.o \
./uart.o \
./ultrasonic.o 

C_DEPS += \
./adc.d \
./button.d \
./buzzer.d \
./captouch.d \
./dht11.d \
./external_eeprom.d \
./fan.d \
./gpio.d \
./lcd.d \
./ldr.d \
./led.d \
./main.d \
./mq2.d \
./pwm.d \
./twi.d \
./uart.d \
./ultrasonic.d 


# Each subdirectory must supply rules for building sources it contributes
%.o: ../%.c subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: AVR Compiler'
	avr-gcc -Wall -g2 -gstabs -Os -fpack-struct -fshort-enums -ffunction-sections -fdata-sections -std=gnu99 -funsigned-char -funsigned-bitfields -mmcu=atmega32 -DF_CPU=16000000UL -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


