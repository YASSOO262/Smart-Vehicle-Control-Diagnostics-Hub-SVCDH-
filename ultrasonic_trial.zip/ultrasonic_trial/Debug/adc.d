adc.o adc.o: ../adc.c ../std_types.h ../adc.h ../common_macros.h

../std_types.h:

../adc.h:

../common_macros.h:
