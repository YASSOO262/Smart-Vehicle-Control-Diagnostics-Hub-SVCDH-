#ifndef UART_H_
#define UART_H_

#include <avr/io.h>
#include <stdint.h> /* For standard uint8_t, uint16_t, etc. */

/*
 * If you are using your own types (like uint8 instead of uint8_t),
 * you can change these to match your existing std_types.h file!
 */

/* --- Function Prototypes --- */

/* Initialize the UART hardware with a specific baud rate (e.g., 9600) */
void UART_init(uint32_t baud_rate);

/* Send a single character/byte */
void UART_sendByte(uint8_t data);

/* Receive a single character/byte (Pauses the program until data arrives) */
uint8_t UART_receiveByte(void);

/* Send a complete text string */
void UART_sendString(const char *Str);

/* Send a number (Converts an integer to readable text) */
void UART_sendInt(int num);

#endif /* UART_H_ */
