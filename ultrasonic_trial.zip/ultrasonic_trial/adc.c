/*
 * adc.c
 *
 *  Created on: Oct 1, 2025
 *      Author: Haneen
 */


#include "std_types.h"
#include "adc.h"
#include "avr/io.h"
#include "common_macros.h"



void ADC_init(ADC_ReferenceVoltage ref_volt, ADC_Prescaler prescaler)
{
	ADMUX = (ADMUX & 0x3F) | (ref_volt<<6);
	ADCSRA = (1<<ADEN) | prescaler;


}


uint16 ADC_readChannel(uint8 channel_num)
{
    ADMUX = (ADMUX & 0xE0) | (channel_num & 0x07); /*  Insert Channel Number */
    SET_BIT(ADCSRA,ADSC); /* Start Conversion : ADSC = 1 */
    while(BIT_IS_CLEAR(ADCSRA,ADIF));
    SET_BIT(ADCSRA, ADIF);
    return ADC;

}
