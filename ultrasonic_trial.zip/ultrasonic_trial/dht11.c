#include "dht11.h"
#include "gpio.h"
#include <util/delay.h>

/* Private function to read 8 bits (1 byte) from the DHT11 */
static uint8 DHT11_readByte(void)
{
    uint8 result = 0;
    uint8 timeout;

    for (uint8 i = 0; i < 8; i++)
    {
        /* Wait for pin to go HIGH */
        timeout = 0;
        while (GPIO_readPin(DHT11_PORT_ID, DHT11_PIN_ID) == LOGIC_LOW)
        {
            _delay_us(2);
            timeout++;
            if (timeout > 50) return 0; /* Prevent infinite loop */
        }

        /* Wait 30us. If it is still HIGH after 30us, the bit is a '1' */
        _delay_us(30);
        if (GPIO_readPin(DHT11_PORT_ID, DHT11_PIN_ID) == LOGIC_HIGH)
        {
            /* Shift a 1 into the specific bit position */
            result |= (1 << (7 - i));

            /* Wait for the pin to go LOW again before reading the next bit */
            timeout = 0;
            while (GPIO_readPin(DHT11_PORT_ID, DHT11_PIN_ID) == LOGIC_HIGH)
            {
                _delay_us(2);
                timeout++;
                if (timeout > 50) return 0;
            }
        }
    }
    return result;
}

uint8 DHT11_read(uint8 *temperature, uint8 *humidity)
{
    uint8 data[5] = {0, 0, 0, 0, 0};
    uint8 timeout;

    /* 1. Send Start Signal */
    GPIO_setupPinDirection(DHT11_PORT_ID, DHT11_PIN_ID, PIN_OUTPUT);
    GPIO_writePin(DHT11_PORT_ID, DHT11_PIN_ID, LOGIC_LOW);
    _delay_ms(20); /* Must be held low for at least 18ms */
    GPIO_writePin(DHT11_PORT_ID, DHT11_PIN_ID, LOGIC_HIGH);
    _delay_us(30);

    /* 2. Set as input to listen for response */
    GPIO_setupPinDirection(DHT11_PORT_ID, DHT11_PIN_ID, PIN_INPUT);

    /* 3. Wait for DHT11 to pull LOW (Response) */
    timeout = 0;
    while (GPIO_readPin(DHT11_PORT_ID, DHT11_PIN_ID) == LOGIC_HIGH)
    {
        _delay_us(2);
        timeout++;
        if (timeout > 50) return DHT11_ERROR;
    }

    /* 4. Wait for DHT11 to pull HIGH */
    timeout = 0;
    while (GPIO_readPin(DHT11_PORT_ID, DHT11_PIN_ID) == LOGIC_LOW)
    {
        _delay_us(2);
        timeout++;
        if (timeout > 50) return DHT11_ERROR;
    }

    /* Wait for it to go LOW again before data starts */
    timeout = 0;
    while (GPIO_readPin(DHT11_PORT_ID, DHT11_PIN_ID) == LOGIC_HIGH)
    {
        _delay_us(2);
        timeout++;
        if (timeout > 50) return DHT11_ERROR;
    }

    /* 5. Read the 5 bytes of data */
    for (uint8 i = 0; i < 5; i++)
    {
        data[i] = DHT11_readByte();
    }

    /* 6. Checksum Verification */
    if (data[0] + data[1] + data[2] + data[3] == data[4])
    {
        *humidity = data[0];
        *temperature = data[2];
        return DHT11_SUCCESS;
    }

    return DHT11_ERROR;
}
