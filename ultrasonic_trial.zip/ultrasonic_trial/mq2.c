/*
 * mq2.c
 *
 *  Created on: Apr 17, 2026
 *      Author: Haneen
 */


#include "mq2.h"
#include "gpio.h"

void MQ2_init(void)
{
    /* Configure the MQ-2 pin as an input pin */
    GPIO_setupPinDirection(MQ2_SENSOR_PORT_ID, MQ2_SENSOR_PIN_ID, PIN_INPUT);
}

boolean MQ2_isGasDetected(void)
{
    /* * Most MQ-2 modules with an LM393 comparator output LOW (0V) when
     * gas/smoke is detected above the threshold set by the potentiometer.
     */
    if(GPIO_readPin(MQ2_SENSOR_PORT_ID, MQ2_SENSOR_PIN_ID) == LOGIC_LOW)
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}
