#include "uart.h"
#include <stdlib.h> /* Required for the itoa() function */

/* Define your microcontroller's speed if it isn't defined globally in your compiler */
#ifndef F_CPU
#define F_CPU 16000000UL /* 16 MHz */
#endif

/* --- Initialization --- */
void UART_init(uint32_t baud_rate) {
    uint16_t ubrr_value = 0;

    /* 1. Enable "Double Speed" mode for better accuracy at 16MHz */
    UCSRA = (1 << U2X);

    /* 2. Enable the Receiver and Transmitter hardware */
    UCSRB = (1 << RXEN) | (1 << TXEN);

    /* 3. Configure the Frame Format
     * URSEL = 1: Required to write to UCSRC register on the ATmega32
     * UCSZ1 & UCSZ0 = 1: Sets data size to 8-bits
     * (Parity is disabled and Stop Bit is 1 by default, which is perfect)
     */
    UCSRC = (1 << URSEL) | (1 << UCSZ0) | (1 << UCSZ1);

    /* 4. Calculate the UBRR Register value based on the requested Baud Rate */
    /* Equation for Double Speed mode (U2X = 1) */
    ubrr_value = (uint16_t)(((F_CPU / (baud_rate * 8UL))) - 1);

    /* 5. Load the calculated value into the Upper and Lower UBRR registers */
    /* URSEL = 0: Required to write to UBRRH */
    UBRRH = ubrr_value >> 8;
    UBRRL = ubrr_value;
}

/* --- Send a Single Byte --- */
void UART_sendByte(uint8_t data) {
    /* Wait until the transmission buffer (UDR) is empty and ready for new data */
    while (!(UCSRA & (1 << UDRE)));

    /* Put the data into the buffer to fire it down the TX pin */
    UDR = data;
}

/* --- Receive a Single Byte --- */
uint8_t UART_receiveByte(void) {
    /* Wait until unread data arrives in the receive buffer */
    while (!(UCSRA & (1 << RXC)));

    /* Read and return the data from the RX pin */
    return UDR;
}

/* --- Send a Text String --- */
void UART_sendString(const char *Str) {
    uint8_t i = 0;

    /* Send bytes one by one until we hit the null-terminator '\0' at the end of the string */
    while (Str[i] != '\0') {
        UART_sendByte(Str[i]);
        i++;
    }
}

/* --- Send an Integer (Number) --- */
void UART_sendInt(int num) {
    char buffer[11]; /* Array to hold the converted string (up to 10 digits + null) */

    /* Convert the integer into a base-10 string (ASCII characters) */
    itoa(num, buffer, 10);

    /* Send the newly created string via UART */
    UART_sendString(buffer);
}
