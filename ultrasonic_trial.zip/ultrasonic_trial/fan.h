/******************************************************************************
 *
 * Module: DC Fan
 *
 * File Name: fan.h
 *
 * Description: Header file for a simple Digital DC Fan driver
 *
 *******************************************************************************/

#ifndef FAN_H_
#define FAN_H_

#include "std_types.h"

/*******************************************************************************
 * Definitions                                                                 *
 *******************************************************************************/

/* Hardware Connection */
#define FAN_PORT_ID PORTC_ID
#define FAN_PIN_ID  PIN4_ID

/*******************************************************************************
 * Functions Prototypes                                                        *
 *******************************************************************************/

/*
 * Description :
 * Initialize the Fan pin as an output pin and ensure the fan is initially OFF.
 */
void Fan_init(void);

/*
 * Description :
 * Turns the Fan ON.
 */
void Fan_on(void);

/*
 * Description :
 * Turns the Fan OFF.
 */
void Fan_off(void);

#endif /* FAN_H_ */
