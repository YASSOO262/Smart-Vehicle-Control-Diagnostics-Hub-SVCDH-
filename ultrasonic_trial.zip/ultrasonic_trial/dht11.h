/*
 * dht11.h
 * Description: DHT11 Temperature & Humidity Sensor Driver
 * Hardware: PB1
 */

#ifndef DHT11_H_
#define DHT11_H_

#include "std_types.h"

#define DHT11_PORT_ID PORTB_ID
#define DHT11_PIN_ID  PIN1_ID

#define DHT11_SUCCESS 1
#define DHT11_ERROR   0

/* * Description: Reads the temperature and humidity from the sensor.
 * Pointers are used so the function can return two values at once.
 * Returns: DHT11_SUCCESS if successful, DHT11_ERROR if disconnected.
 */
uint8 DHT11_read(uint8 *temperature, uint8 *humidity);

#endif /* DHT11_H_ */
