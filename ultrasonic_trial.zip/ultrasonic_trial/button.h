#ifndef BUTTON_H_
#define BUTTON_H_

#include "std_types.h"
#include "gpio.h"

/* Mute Button (Hardware Interrupt) on PD2 */
#define MUTE_BUTTON_PORT_ID       PORTD_ID
#define MUTE_BUTTON_PIN_ID        PIN2_ID

/* Single Security Toggle Button on PD4 */
#define SECURITY_BUTTON_PORT_ID   PORTD_ID
#define SECURITY_BUTTON_PIN_ID    PIN4_ID

/* Function Prototypes */
void PushButton_Interrupt_Init(void);
void SecurityButton_Init(void);
uint8 isSecurityButtonPressed(void);

#endif /* BUTTON_H_ */
