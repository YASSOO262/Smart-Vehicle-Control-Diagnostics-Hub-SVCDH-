#include "lcd.h"
#include "external_eeprom.h"
#include "twi.h"
#include "adc.h"
#include "pwm.h"
#include "gpio.h" /* Added for the PC2 LED */
#include <util/delay.h>
#include <avr/interrupt.h>

/* --- Sensor Drivers --- */
#include "ultrasonic.h"
#include "dht11.h"
#include "mq2.h"
#include "captouch.h"
#include "buzzer.h"
#include "fan.h"
#include "button.h"
#include "uart.h"

#define LOG_ADDR 0x0010

/* --- GLOBAL VARIABLES FOR THE BUZZER ISR --- */
volatile uint16 g_buzzer_delay_ms = 0;
volatile uint8  g_critical_alarm = 0;
volatile uint8 isMuted = FALSE;

/* --- TIMER 2 CONFIGURATION (1ms Tick) --- */
void Timer2_CTC_Init(void) {
	TCNT2 = 0;
	OCR2  = 250; /* 250 ticks @ 4us per tick = 1 millisecond */
	TIMSK |= (1<<OCIE2); /* Enable Timer2 Compare Match Interrupt */
	/* CTC Mode, Prescaler = 64 (F_CPU 16MHz / 64 = 250kHz) */
	TCCR2 = (1<<FOC2) | (1<<WGM21) | (1<<CS22);
}

/* --- THE BACKGROUND BUZZER BRAIN --- */
/* This runs invisibly every 1 millisecond, no matter what main() is doing */
ISR(TIMER2_COMP_vect) {
	static uint16 ms_counter = 0;
	static uint8 buzzer_state = 0;

	if (g_critical_alarm) {
		Buzzer_on();
		ms_counter = 0;
	}
	else if (g_buzzer_delay_ms > 0) {
		ms_counter++;
		if (ms_counter >= g_buzzer_delay_ms) {
			ms_counter = 0;
			buzzer_state ^= 1; /* Flip state between 1 and 0 */
			if (buzzer_state) Buzzer_on();
			else Buzzer_off();
		}
	}
	else {
		Buzzer_off();
		ms_counter = 0;
		buzzer_state = 0;
	}
}

ISR(INT0_vect) {
	isMuted = TRUE; // Latch the mute state
}

/* --- DIAGNOSTIC DISPLAY --- */
void Display_Diagnostic(uint8 fault_id) {
	LCD_clearScreen();
	LCD_displayString("CODE: ");
	switch(fault_id) {
	case 1: LCD_displayString("P001"); LCD_moveCursor(1,0); LCD_displayString("DIST < 10CM"); break;
	case 2: LCD_displayString("P002"); LCD_moveCursor(1,0); LCD_displayString("TEMP > 25 C"); break;
	case 3: LCD_displayString("P003"); LCD_moveCursor(1,0); LCD_displayString("SMOKE DETECTED"); break;
	case 4: LCD_displayString("P004"); LCD_moveCursor(1,0); LCD_displayString("SEC. BREACH"); break;
	default: LCD_displayString("SYSTEM OK"); LCD_moveCursor(1,0); LCD_displayString("NO FAULTS");
	}
}

int main(void) {
	TWI_ConfigType i2c_bus = {0x01, 400000};

	uint8 current_temp = 0, current_hum = 0;
	uint8 temp_high_flag = 0;
	uint8 dht_read_timer = 8; /* Counter to prevent reading DHT11 too fast */

	uint16 ldr_val = 0;
	uint16 distance = 0;

	uint8 fault_to_log = 0;
	uint8 last_logged_fault = 255;
	uint8 system_locked = 1;

	/* --- 1. Init Hardware --- */
	LCD_init();
	TWI_init(&i2c_bus);
	ADC_init(AVCC, F_CPU_128);
	Timer2_CTC_Init(); /* Start our background buzzer timer! */
	UART_init(9600);

	Ultrasonic_init();
	MQ2_init();
	Touch_init();
	Buzzer_init();
	Fan_init();

	/* Buttons & Indicator LED */
	PushButton_Interrupt_Init();
	SecurityButton_Init();
	GPIO_setupPinDirection(PORTC_ID, PIN2_ID, PIN_OUTPUT);
	GPIO_writePin(PORTC_ID, PIN2_ID, LOGIC_HIGH); /* Default system to Locked (LED ON) */

	sei(); /* Enable Global Interrupts */

	while(1) {
		fault_to_log = 0;

		/* --- 2. SECURITY TOGGLE LOGIC (PD4) --- */
		if (isSecurityButtonPressed()) {
			_delay_ms(30); /* Software debounce */

			if (isSecurityButtonPressed()) {
				system_locked ^= 1; /* Toggle lock state */

				/* Turn the LED on PC2 ON or OFF based on the new state */
				/* Notice: ALL LCD code is removed from here! */
				if (system_locked == 1) {
					GPIO_writePin(PORTC_ID, PIN2_ID, LOGIC_HIGH); /* Locked -> LED ON */
				} else {
					GPIO_writePin(PORTC_ID, PIN2_ID, LOGIC_LOW);  /* Unlocked -> LED OFF */
				}

				while(isSecurityButtonPressed()) { } /* Wait for button release */
			}
		}

		/* --- 3. LDR & LED LOGIC (THRESHOLD + SMOOTH FADE) --- */
		ldr_val = ADC_readChannel(7);

		if (ldr_val <= 150) {
			PWM_Timer0_Start(0); /* Completely OFF in the dark */
		} else {
			/* Smoothly fade from 0 to 255 as the LDR goes from 151 to 1023 */
			uint8 brightness = (uint8)(((uint32_t)(ldr_val - 150) * 255) / (1023 - 150));
			PWM_Timer0_Start(brightness);
		}

		/* --- 4. SENSOR READINGS --- */
		distance = Ultrasonic_readDistance();
		uint8 gas_detected = MQ2_isGasDetected();
		uint8 touch_detected = Touch_getState();

		/* DHT11 Protection Logic: Only read it once every 2 seconds (8 loops * 250ms) */
		dht_read_timer++;
		if (dht_read_timer >= 8) {
			dht_read_timer = 0;
			if (DHT11_read(&current_temp, &current_hum) == DHT11_SUCCESS) {

				UART_sendString("\r\n--- System Report ---\r\n");

				UART_sendString("Temperature: ");
				UART_sendInt(current_temp);
				UART_sendString(" C\r\n");

				UART_sendString("Humidity: ");
				UART_sendInt(current_hum);
				UART_sendString(" %\r\n");

				UART_sendString("Distance: ");
				UART_sendInt(distance);
				UART_sendString(" cm\r\n");

				if (current_temp > 25) {
					temp_high_flag = 1;
					Fan_on();
				} else {
					temp_high_flag = 0;
					Fan_off();
				}
			}
		}

		/* --- 5. SETTING THE BACKGROUND BUZZER RULES --- */

		/* STEP A: Reset the Mute Flag if the environment is safe again. */
		if (gas_detected == FALSE && temp_high_flag == 0 && distance >= 20 && touch_detected == LOGIC_LOW) {
			isMuted = FALSE;
		}

		/* STEP B: Apply the Buzzer Rules (Respecting the Mute Flag!) */
		if (isMuted == TRUE) {
			/* Force the background timer to stay quiet */
			g_critical_alarm = 0;
			g_buzzer_delay_ms = 0;
		}
		else {
			/* Normal Operation: Sound alarms if conditions are met! */
			/* The logic "system_locked && touch_detected == LOGIC_HIGH" is handled right here */
			if (gas_detected == TRUE || (system_locked && touch_detected == LOGIC_HIGH)) {
				g_critical_alarm = 1;
			} else {
				g_critical_alarm = 0;
				/* Distance logic */
				if (distance < 10) { g_buzzer_delay_ms = 100; }
				else if (distance >= 10 && distance < 20) { g_buzzer_delay_ms = 250; }
				else if (distance >= 20 && distance < 30) { g_buzzer_delay_ms = 500; }
				else { g_buzzer_delay_ms = 0; }
			}
		}

		/* --- 6. FAULT PRIORITY LADDER --- */
		if (gas_detected == TRUE) { fault_to_log = 3; }
		else if (system_locked && touch_detected == LOGIC_HIGH) { fault_to_log = 4; }
		else if (temp_high_flag) { fault_to_log = 2; }
		else if (distance < 10) { fault_to_log = 1; }

		/* --- 7. EEPROM STORAGE --- */
		EEPROM_readByte(LOG_ADDR, &last_logged_fault);
		if (fault_to_log != last_logged_fault) {
			EEPROM_writeByte(LOG_ADDR, fault_to_log);
			_delay_ms(10);
		}

		/* --- 8. DISPLAY LOGIC (Anti-Flicker) --- */
		static uint8 current_displayed_fault = 255;
		if (fault_to_log != current_displayed_fault) {
			Display_Diagnostic(fault_to_log);
			current_displayed_fault = fault_to_log;
		}

		/* A highly stable 250ms master loop */
		_delay_ms(250);
	}
}
