/*
 * buzzer.c
 */

#include "buzzer.h"
#include "gpio.h"

void Buzzer_init(void)
{
    /* Setup PC5 as output */
    GPIO_setupPinDirection(BUZZER_PORT_ID, BUZZER_PIN_ID, PIN_OUTPUT);

    /* Ensure the buzzer starts in the OFF state */
    Buzzer_off();
}

void Buzzer_on(void)
{
    GPIO_writePin(BUZZER_PORT_ID, BUZZER_PIN_ID, LOGIC_HIGH);
}

void Buzzer_off(void)
{
    GPIO_writePin(BUZZER_PORT_ID, BUZZER_PIN_ID, LOGIC_LOW);
}

void Buzzer_toggle(void)
{
    /* Reads the current pin state and flips it using the GPIO driver */
    if (GPIO_readPin(BUZZER_PORT_ID, BUZZER_PIN_ID) == LOGIC_HIGH)
    {
        Buzzer_off();
    }
    else
    {
        Buzzer_on();
    }
}
