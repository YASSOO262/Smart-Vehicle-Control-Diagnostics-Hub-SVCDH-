/*
 * pwm.c
 *
 *  Created on: Sep 26, 2025
 *      Author: Haneen
 */


#include "pwm.h"


void PWM_Timer0_Start(uint8 duty_cycle)
{
	TCNT0 = 0;  /* Timer equal zero */
	TCCR0 = 0;
	TCCR0 = (1 << WGM00) | (1 << WGM01) | (1 << COM01); /* Fast pwm, non inverting */
	TCCR0 |= (1 << CS00) | (1 << CS02);	/* Prescalar is F_CPU/1024  */

	DDRB |= (1 << PB3);
	if (duty_cycle > 100) /* Safety to prevent overflow */
	{
		duty_cycle = 100;
	}

	OCR0 = (uint8)((duty_cycle * 255) / 100);

}
