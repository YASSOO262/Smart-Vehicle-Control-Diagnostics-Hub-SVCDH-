/*
 * ultrasonic.c
 *
 * Description: Interrupt-Driven Digital Ultrasonic Sensor Driver (HC-SR04)
 */

/* Define the CPU frequency to 16MHz for the _delay_us() function to work correctly */
#ifndef F_CPU
#define F_CPU 16000000UL
#endif

#include "ultrasonic.h"
#include "gpio.h"
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

/*******************************************************************************
 * Global Variables                                                            *
 *******************************************************************************/

/* Volatile variables are required because they are modified inside the ISR */
static volatile uint8 g_edgeCount = 0;
static volatile uint16 g_timeHigh = 0;

/*******************************************************************************
 * Interrupt Service Routine (ISR)                                             *
 *******************************************************************************/

/* ISR for External Interrupt 1 (INT1) connected to PD3 */
ISR(INT1_vect)
{
    Ultrasonic_edgeProcessing();
}

/*******************************************************************************
 * Functions Definitions                                                       *
 *******************************************************************************/

void Ultrasonic_init(void)
{
    /* 1. Configure the GPIO Pins */
    GPIO_setupPinDirection(ULTRASONIC_TRIGGER_PORT_ID, ULTRASONIC_TRIGGER_PIN_ID, PIN_OUTPUT);
    GPIO_writePin(ULTRASONIC_TRIGGER_PORT_ID, ULTRASONIC_TRIGGER_PIN_ID, LOGIC_LOW); /* Ensure it starts LOW */

    GPIO_setupPinDirection(ULTRASONIC_ECHO_PORT_ID, ULTRASONIC_ECHO_PIN_ID, PIN_INPUT);

    /* 2. Configure Timer1
     * Mode: Normal (TCCR1A = 0)
     * Prescaler: F_CPU/8 (CS11 = 1 in TCCR1B)
     * At 16MHz, the timer clock is 2MHz (0.5 microseconds per tick).
     */
    TCCR1A = 0;
    TCCR1B = (1 << CS11);
    TCNT1 = 0;

    /* 3. Configure External Interrupt 1 (INT1)
     * Trigger: Rising Edge initially (ISC11 = 1, ISC10 = 1 in MCUCR)
     */
    MCUCR |= (1 << ISC11) | (1 << ISC10);

    /* Enable INT1 in the General Interrupt Control Register (GICR) */
    GICR |= (1 << INT1);
}

void Ultrasonic_Trigger(void)
{
    /* Send a 10us HIGH pulse to the Trigger pin to initiate the acoustic wave */
    GPIO_writePin(ULTRASONIC_TRIGGER_PORT_ID, ULTRASONIC_TRIGGER_PIN_ID, LOGIC_HIGH);
    _delay_us(10);
    GPIO_writePin(ULTRASONIC_TRIGGER_PORT_ID, ULTRASONIC_TRIGGER_PIN_ID, LOGIC_LOW);
}

uint16 Ultrasonic_readDistance(void)
{
    uint16 distance = 0;

    /* Reset the state machine for a new reading */
    g_edgeCount = 0;

    /* Fire the acoustic wave */
    Ultrasonic_Trigger();

    /* * Fail-Safe Polling Loop:
     * We wait here for the ISR to capture the returning echo.
     * At F_CPU/8 (2MHz), Timer1 (TCNT1) reaches 60,000 in 30 milliseconds.
     * If 30ms pass, the wave is lost (or the object is over 5 meters away).
     */
    while(g_edgeCount != 2)
    {
        /* Timeout Triggered! Break the loop so the car's CPU doesn't freeze. */
        if (TCNT1 > 60000)
        {
            /* Reset the state machine to prevent false triggers later */
            g_edgeCount = 0;

            /* Reconfigure INT1 back to default Rising Edge just in case it got stuck */
            MCUCR |= (1 << ISC10);

            return ULTRASONIC_ERROR; /* Return 0xFFFF */
        }
    }

    /* * Distance Calculation for 16MHz CPU:
     * Timer Clock = 16 MHz / 8 = 2 MHz (Tick Time = 0.5 us)
     * Speed of Sound = 34300 cm/s
     * Distance = (Speed * Time) / 2
     * Distance = (34300 * (g_timeHigh * 0.0000005)) / 2
     * Distance = (343 * g_timeHigh) / 40000
     */
    distance = (uint16)(((uint32)g_timeHigh * 343) / 40000);

    return distance;
}

void Ultrasonic_edgeProcessing(void)
{
    /* State 0: The echo pin just went HIGH (sound wave sent out, timing starts) */
    if(g_edgeCount == 0)
    {
        /* Clear Timer1 to start measuring from zero */
        TCNT1 = 0;

        /* Reconfigure INT1 to trigger on a Falling Edge (when the echo returns):
         * ISC11 = 1, ISC10 = 0
         */
        MCUCR &= ~(1 << ISC10);

        g_edgeCount = 1;
    }
    /* State 1: The echo pin just went LOW (sound wave returned, timing ends) */
    else if(g_edgeCount == 1)
    {
        /* Capture the timer value representing the total pulse duration */
        g_timeHigh = TCNT1;

        /* Reconfigure INT1 back to trigger on a Rising Edge for the next ping:
         * ISC11 = 1, ISC10 = 1
         */
        MCUCR |= (1 << ISC10);

        g_edgeCount = 2;
    }
}
