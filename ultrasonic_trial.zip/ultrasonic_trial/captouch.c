#include "captouch.h"
#include "gpio.h"

void Touch_init(void) {
    /* Set PD2 as Input */
    GPIO_setupPinDirection(TOUCH_PORT_ID, TOUCH_PIN_ID, PIN_INPUT);
}

uint8 Touch_getState(void) {
    /* Read the digital value of PD2 */
    return GPIO_readPin(TOUCH_PORT_ID, TOUCH_PIN_ID);
}
