/*
 * buzzer.h
 *
 * Description: Digital Buzzer Driver (Active/Passive Digital Mode)
 * Hardware connection: PC5
 */

#ifndef BUZZER_H_
#define BUZZER_H_

#include "std_types.h"

#define BUZZER_PORT_ID  PORTC_ID
#define BUZZER_PIN_ID   PIN5_ID

/* Initializes the buzzer pin as an output and ensures it is turned off */
void Buzzer_init(void);

/* Turns the buzzer ON */
void Buzzer_on(void);

/* Turns the buzzer OFF */
void Buzzer_off(void);

/* Flips the buzzer state (If ON, turns OFF. If OFF, turns ON) */
void Buzzer_toggle(void);

#endif /* BUZZER_H_ */
