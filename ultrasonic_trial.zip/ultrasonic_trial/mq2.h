#ifndef MQ2_SENSOR_H_
#define MQ2_SENSOR_H_

#include "std_types.h"

/* MQ-2 Digital Out connected to PB0 */
#define MQ2_SENSOR_PORT_ID PORTB_ID
#define MQ2_SENSOR_PIN_ID  PIN0_ID

void MQ2_init(void);
boolean MQ2_isGasDetected(void);

#endif /* MQ2_SENSOR_H_ */
