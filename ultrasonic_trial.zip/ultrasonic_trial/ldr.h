#ifndef LDR_H_
#define LDR_H_

#include "std_types.h"

#define LDR_SENSOR_CHANNEL 7

uint16 LDR_getLightIntensity(void);

#endif
