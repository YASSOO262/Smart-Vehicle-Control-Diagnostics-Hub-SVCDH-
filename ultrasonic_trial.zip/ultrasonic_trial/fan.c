/*
 * fan.c
 *
 *  Created on: Apr 17, 2026
 *      Author: Haneen
 */


/******************************************************************************
 *
 * Module: DC Fan
 *
 * File Name: fan.c
 *
 * Description: Source file for a simple Digital DC Fan driver
 *
 *******************************************************************************/

#include "fan.h"
#include "gpio.h"

void Fan_init(void)
{
    /* Configure the Fan pin as an output pin */
    GPIO_setupPinDirection(FAN_PORT_ID, FAN_PIN_ID, PIN_OUTPUT);

    /* Ensure the fan is turned off at startup */
    GPIO_writePin(FAN_PORT_ID, FAN_PIN_ID, LOGIC_LOW);
}

void Fan_on(void)
{
    /* Output logic HIGH to turn on the fan */
	 GPIO_writePin(FAN_PORT_ID, FAN_PIN_ID, LOGIC_HIGH);
}

void Fan_off(void)
{
    /* Output logic LOW to turn off the fan */
	GPIO_writePin(FAN_PORT_ID, FAN_PIN_ID, LOGIC_LOW);

}
