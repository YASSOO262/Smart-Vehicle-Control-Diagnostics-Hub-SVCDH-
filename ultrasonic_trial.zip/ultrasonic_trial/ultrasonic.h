/*
 * ultrasonic.h
 *
 * Description: Interrupt-Driven Digital Ultrasonic Sensor Driver (HC-SR04)
 * Hardware: ATmega32 (ETA32-MINI)
 */

#ifndef ULTRASONIC_H_
#define ULTRASONIC_H_

#include "std_types.h"

/*******************************************************************************
 * Hardware Configuration Definitions                                          *
 *******************************************************************************/

/* Trigger Pin: Moved to PD6 to protect the Timer2 (PD7) PWM signal */
#define ULTRASONIC_TRIGGER_PORT_ID  PORTD_ID
#define ULTRASONIC_TRIGGER_PIN_ID   PIN6_ID

/* Echo Pin: Must remain on PD3 to utilize External Interrupt 1 (INT1) */
#define ULTRASONIC_ECHO_PORT_ID     PORTD_ID
#define ULTRASONIC_ECHO_PIN_ID      PIN3_ID

/* Error code returned if the ultrasonic sensor times out / loses signal */
#define ULTRASONIC_ERROR            0xFFFF

/*******************************************************************************
 * Functions Prototypes                                                        *
 *******************************************************************************/

/*
 * Description: Initializes Timer1, INT1, and the GPIO pins.
 */
void Ultrasonic_init(void);

/*
 * Description: Sends a 10-microsecond HIGH pulse to the ultrasonic trigger pin.
 */
void Ultrasonic_Trigger(void);

/*
 * Description: Starts the measurement, waits for the interrupt to capture edges,
 * calculates distance, and features a fail-safe timeout.
 * Returns: Distance in centimeters, or ULTRASONIC_ERROR (0xFFFF) if signal is lost.
 */
uint16 Ultrasonic_readDistance(void);

/*
 * Description: The Interrupt Service Routine (ISR) logic for INT1.
 */
void Ultrasonic_edgeProcessing(void);

#endif /* ULTRASONIC_H_ */
