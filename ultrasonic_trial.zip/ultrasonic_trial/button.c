#include "button.h"
#include <avr/io.h>
#include <avr/interrupt.h>

void PushButton_Interrupt_Init(void) {
    /* 1. Configure PD2 as an input pin */
    GPIO_setupPinDirection(MUTE_BUTTON_PORT_ID, MUTE_BUTTON_PIN_ID, PIN_INPUT);

    /* 2. Enable the internal pull-up resistor on PD2 */
    GPIO_writePin(MUTE_BUTTON_PORT_ID, MUTE_BUTTON_PIN_ID, LOGIC_HIGH);

    /* 3. Configure INT0 to trigger on a FALLING EDGE */
    MCUCR |= (1 << ISC01);
    MCUCR &= ~(1 << ISC00);

    /* 4. Enable External Interrupt Request 0 (INT0) */
    GICR  |= (1 << INT0);

    /* 5. Enable Global Interrupts (I-bit in SREG) */
    SREG  |= (1 << 7);
}

void SecurityButton_Init(void) {
    /* Set PD4 as Input */
    GPIO_setupPinDirection(SECURITY_BUTTON_PORT_ID, SECURITY_BUTTON_PIN_ID, PIN_INPUT);

    /* Enable internal pull-up resistor so it stays HIGH until pressed */
    GPIO_writePin(SECURITY_BUTTON_PORT_ID, SECURITY_BUTTON_PIN_ID, LOGIC_HIGH);
}

uint8 isSecurityButtonPressed(void) {
    if (GPIO_readPin(SECURITY_BUTTON_PORT_ID, SECURITY_BUTTON_PIN_ID) == LOGIC_LOW) {
        return TRUE;
    }
    return FALSE;
}
