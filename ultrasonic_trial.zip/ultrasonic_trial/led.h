#ifndef LED_H_
#define LED_H_

#include "std_types.h"

/* LED is connected to PB3 (OC0) */
#define LED_PORT_DIR DDRB
#define LED_PIN      PB3

/*
 * Function to initialize Timer0 in Fast PWM mode
 * and setup PB3 as an output pin.
 */
void LED_init(void);

/*
 * Function to set the LED brightness
 * duty_cycle: 0 (Off) to 255 (Max Brightness)
 */
void LED_setIntensity(uint8 duty_cycle);

#endif /* LED_H_ */
