/*
 * adc.h
 *
 *  Created on: Oct 1, 2025
 *      Author: Haneen
 */

#ifndef ADC_H_
#define ADC_H_

typedef enum
{
	F_CPU_2 = 1,
	F_CPU_4,
	F_CPU_8,
	F_CPU_16,
	F_CPU_32,
	F_CPU_64,
	F_CPU_128,
} ADC_Prescaler;


typedef enum
{
	AREF, /* External AREF: REFS1, REFS0 = 0 */
	AVCC, /* AVCC with External Capacitor : REFS1 = 0, REFS0 = 1 */
	INTERNAL_2_56_V = 3, /* Internal 2.56V : REFS1, REFS0 = 1 */

} ADC_ReferenceVoltage;


typedef struct
{
	ADC_ReferenceVoltage ref_volt;
	ADC_Prescaler prescaler;

} ADC_Config ;


void ADC_init(ADC_ReferenceVoltage ref_volt, ADC_Prescaler prescaler);
uint16 ADC_readChannel(uint8 channel_num);


#endif /* ADC_H_ */
